class Subject:
    def __init__(self, name, teacher_id):
        self.name = name
        self.teacher_id = teacher_id

    def save_to_db(self, conn):
        with conn:
            conn.execute(
                "INSERT INTO subjects (name, teacher_id) VALUES (?, ?)",
                (self.name, self.teacher_id),
            )