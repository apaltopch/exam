class Teacher:
    def __init__(self, name):
        self.name = name

    def save_to_db(self, conn):
        with conn:
            conn.execute("INSERT INTO teachers (name) VALUES (?)", (self.name,))