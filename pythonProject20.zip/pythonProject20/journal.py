import openpyxl

class Journal:
    def __init__(self, conn):
        self.conn = conn

    def get_teacher_report(self, teacher_id):
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                lessons.date, 
                subjects.name AS subject_name, 
                groups.name AS group_name, 
                lessons.attendance
            FROM lessons
            JOIN subjects ON lessons.subject_id = subjects.id
            JOIN groups ON lessons.group_id = groups.id
            WHERE subjects.teacher_id = ?
        """, (teacher_id,))
        return cursor.fetchall()

    def export_to_excel(self, teacher_id, filename):
        report_data = self.get_teacher_report(teacher_id)
        if not report_data:
            raise ValueError("Нет данных для отчета")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Отчет по нагрузке"
        ws.append(["Дата", "Дисциплина", "Группа", "Посещаемость"])

        for row in report_data:
            ws.append(row)

        wb.save(filename)