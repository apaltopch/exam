import sqlite3

def create_database():
    conn = sqlite3.connect("journal.db")
    with conn:
        conn.execute("CREATE TABLE IF NOT EXISTS teachers (id INTEGER PRIMARY KEY, name TEXT)")
        conn.execute("CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY, name TEXT)")
        conn.execute("CREATE TABLE IF NOT EXISTS subjects (id INTEGER PRIMARY KEY, name TEXT, teacher_id INTEGER)")
        conn.execute("CREATE TABLE IF NOT EXISTS lessons (id INTEGER PRIMARY KEY, date TEXT, subject_id INTEGER, group_id INTEGER, attendance INTEGER)")
    return conn