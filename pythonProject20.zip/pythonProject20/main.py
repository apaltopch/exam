import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QMessageBox
from database import create_database
from teacher import Teacher
from group import Group
from subject import Subject
from lesson import Lesson
from journal import Journal
from form1 import Ui_MainWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.conn = create_database()
        self.ui.pushButton.clicked.connect(self.save_data)
        self.ui.pushButton_2.clicked.connect(self.export_report)

    def save_data(self):
        teacher_name = self.ui.lineEdit.text()
        group_name = self.ui.lineEdit_2.text()
        subject_name = self.ui.lineEdit_3.text()

        if not (teacher_name and group_name and subject_name):
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return

        teacher = Teacher(teacher_name)
        teacher.save_to_db(self.conn)

        group = Group(group_name)
        group.save_to_db(self.conn)

        teacher_id = self.conn.execute("SELECT id FROM teachers WHERE name = ?", (teacher_name,)).fetchone()[0]
        group_id = self.conn.execute("SELECT id FROM groups WHERE name = ?", (group_name,)).fetchone()[0]

        subject = Subject(subject_name, teacher_id)
        subject.save_to_db(self.conn)

        subject_id = self.conn.execute("SELECT id FROM subjects WHERE name = ?", (subject_name,)).fetchone()[0]
        lesson = Lesson("2024-12-24", subject_id, group_id, 15)
        lesson.save_to_db(self.conn)

        QMessageBox.information(self, "Успех", "Данные сохранены!")

    def export_report(self):
        teacher_name = self.ui.lineEdit.text()
        teacher_id = self.conn.execute("SELECT id FROM teachers WHERE name = ?", (teacher_name,)).fetchone()

        if not teacher_id:
            QMessageBox.warning(self, "Ошибка", "Преподаватель не найден!")
            return

        teacher_id = teacher_id[0]
        journal = Journal(self.conn)
        try:
            journal.export_to_excel(teacher_id, "teacher_report.xlsx")
            QMessageBox.information(self, "Успех", "Отчет экспортирован!")
        except ValueError as e:
            QMessageBox.warning(self, "Ошибка", str(e))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())