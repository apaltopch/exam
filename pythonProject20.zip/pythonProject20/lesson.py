class Lesson:
    def __init__(self, date, subject_id, group_id, attendance):
        self.date = date
        self.subject_id = subject_id
        self.group_id = group_id
        self.attendance = attendance

    def save_to_db(self, conn):
        with conn:
            conn.execute(
                "INSERT INTO lessons (date, subject_id, group_id, attendance) VALUES (?, ?, ?, ?)",
                (self.date, self.subject_id, self.group_id, self.attendance),
            )